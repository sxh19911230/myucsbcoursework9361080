// sysopenfile.cc
//

#include "sysopenfile.h"

