// useropenfile.cc
//

#include "useropenfile.h"
